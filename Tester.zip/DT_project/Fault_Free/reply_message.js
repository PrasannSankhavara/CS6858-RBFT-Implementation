class Reply_Message {
    constructor(messageType, rid, sender) {
      this.messageType = messageType;
      this.rid= rid;
      this.sender = sender;
    }
  }
  
  module.exports = Reply_Message;
  